<?php
  $conServer = "localhost";
  $conUsername = "root";
  $conPassword = "";
  $conDBName = "minbank";
$conn = mysqli_connect($conServer, $conUsername, $conPassword, $conDBName);
?>
