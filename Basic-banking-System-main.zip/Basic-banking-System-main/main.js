function executeform(No, Name, Mail){
  var nme = Name;
  var eml = Mail;
  var no = No;
  document.getElementById("sname").value = nme;
  document.getElementById("smail").value = eml;
}

function f1(){
    var usersno = 1;
    var username = "Himanshu Malviya";
    var useremail = "himanshu135@gmail.com";
    executeform(usersno, username, useremail);
}
function f2(){
    var usersno = 2;
    var username = "Amit Nijamra";
    var useremail = "amit14@gmail.com";
    executeform(usersno, username, useremail);
}
function f3(){
    var usersno = 3;
    var username = "Utsav L.";
    var useremail = "utsavjain55@gmail.com";
    executeform(usersno, username, useremail);
}
function f4(){
    var usersno = 4;
    var username = "Shourya Patidar";
    var useremail = "lolopat21@gmail.com";
    executeform(usersno, username, useremail);
}
function f5(){
    var usersno = 5;
    var username = "Varnin Meshloop";
    var useremail = "gohan100@gmail.com";
    executeform(usersno, username, useremail);
}
function f6(){
    var usersno = 6;
    var username = "Jatin Chaaw";
    var useremail = "jatiniyabjp34@gmail.com";
    executeform(usersno, username, useremail);
}
function f7(){
    var usersno = 7;
    var username = "Bishal Kumar";
    var useremail = "vishal619@gmail.com";
    executeform(usersno, username, useremail);
}
function f8(){
    var usersno = 8;
    var username = "Gyanendra Singh";
    var useremail = "gyanib14@gmail.com";
    executeform(usersno, username, useremail);
}
function f9(){
    var usersno = 9;
    var username = "Jay Tilgota";
    var useremail = "jaytel84@gmail.com";
    executeform(usersno, username, useremail);
}
function f10(){
    var usersno = 10;
    var username = "Yash Jain";
    var useremail = "yashnhp71@gmail.com";
    executeform(usersno, username, useremail);
}
